function drop
%DROP Remove one disc from Niki's cargo and put it to the field.

%
% Stephan Rave (stephan.rave@wwu.de) - 2012/10/12
%

% just call the corresponding german named function
gib_ab;

end