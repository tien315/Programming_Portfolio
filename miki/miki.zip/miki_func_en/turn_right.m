function turn_right
%TURN_RIGHT Turn Niki 90 degrees clockwise.

%
% Stephan Rave (stephan.rave@wwu.de) - 2012/10/12
%

% just call the corresponding german named function
drehe_rechts;

end