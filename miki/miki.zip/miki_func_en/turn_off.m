function turn_off
%TURN_OFF Set Niki to halting state.

%
% Stephan Rave (stephan.rave@wwu.de) - 2012/10/12
%

% just call the corresponding german named function
abschalten;

end
